/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: OurStack.java
 * Author: Frank M. Carrano
 * Author: Timothy M. Henry
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment03PartB;

import java.util.EmptyStackException;

public class OurStack<T> implements StackInterface<T> {
    private Node firstNode;

    public OurStack() {
        firstNode = null;
    }

    @Override
    public void push(T newEntry) {
        firstNode = new Node(newEntry, firstNode);
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return firstNode.data;
    }

    @Override
    public T pop() {
        T top = peek();
        firstNode = firstNode.next;
        return top;
    }

    @Override
    public boolean isEmpty() {
        return firstNode == null;
    }

    @Override
    public void clear() {
        firstNode = null;
    }

    private class Node {
        private T data;
        private Node next;

        private Node(T dataSector) {
            this(dataSector, null);
        }

        private Node(T dataSector, Node nextSector) {
            data = dataSector;
            next = nextSector;
        }

        private T getData() {
            return data;
        }

        private void setData(T newData) {
            data = newData;
        }

        private Node getNextNode() {
            return next;
        }
        private void setNextNode(Node nextSector) {
            next = nextSector;
        }
    }
}
