/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: LinkedBag.java
 * Author: Frank M. Carrano
 * Author: Timothy M. Henry
 * Author: Duc Ta
 * Author: Monique Johnson
 * **********************************************
 */

package assignment03PartA;

import java.util.HashSet;

public final class LinkedBag<T> implements PrimaryDataStructureBagInterface<T> {

    private Node firstNode;
    private int numOfEntries;

    public LinkedBag() {
        firstNode = null;
        numOfEntries = 0;
    }
    @Override
    public boolean isEmpty() {
        return numOfEntries == 0;
    }
    @Override
    public int getCurrentSize() {
        return numOfEntries;
    }
    @Override
    public boolean add(T newEntry) {
        Node newNode = new Node(newEntry);
        if (firstNode == null) {
            firstNode = newNode;
        } else {
            Node currentNode = firstNode;
            while (currentNode.next != null) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
        }
        numOfEntries++;
        return true;
    }

    @Override
    public boolean removeAllOccurrences(T[][] entries) {
        if (entries.length == 0) {
            return false;
    }


        System.out.println("[+] Removing all occurrences of from the bag...");
        System.out.println("[-] Converting 2D array to 1D...");

        HashSet<T> uniqueVals = new HashSet<>();
        for (T[] row : entries) {
            for (T entry : row) {
                    uniqueVals.add(entry);
                }
            }
            System.out.println("[-] Removing duplicates in 1D...\n[>] The final 1D array now contains:");
            for (T entry : uniqueVals) {
                System.out.print(entry + " ");
            }
            System.out.println();

            System.out.println("[-] Removing the final 1D array items from the bag...");
            for (T entry : uniqueVals) {
                remove(entry);
            }
            return true;
        }
        private boolean remove (T entry) {
            while (firstNode != null && firstNode.data.equals(entry)) {
                firstNode = firstNode.next;
                numOfEntries--;
            }

            Node currentNode = firstNode;
            while (currentNode != null && currentNode.next != null) {
                if (currentNode.next.data.equals(entry)) {
                    currentNode.next = currentNode.next.next;
                    numOfEntries--;
                } else {
                    currentNode = currentNode.next;
                }
            }
            return true;
        }

    @Override
    public T[] toArray() {
        @SuppressWarnings("unchecked")
        T[] result = (T[]) new Object[numOfEntries];
        int index = 0;
        Node currentNode = firstNode;
        while ((index < numOfEntries) && (currentNode != null)) {
            result[index] = currentNode.data;
            index++;
            currentNode = currentNode.next;
        }
        return result;
    }
    private class Node {
        private T data;
        private Node next;

        private Node(T dataSector) {
            this.data = dataSector;
        }
        private Node(T dataSector, Node nextSector) {
            data = dataSector;
            next = nextSector;
        }
    }
}
