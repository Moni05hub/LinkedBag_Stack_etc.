/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: PascalsTriangleGenerator.java
 * Author: Java Foundation
 * Author: Duc Ta
 * Author: Monique Johnson
 * **********************************************
 */

package assignment03PartD;

public class PascalsTriangleGenerator {

    public PascalsTriangleGenerator() {
    }

    public int[] computeRow(int rowComputation) {
        int[] row = new int[rowComputation];
        row[0] = 1;
        for (int i = 1; i < rowComputation; i++) {
            row[i] = (int) ((long) row[i - 1] * (rowComputation - i + 1) / i);
        }
        return new int[rowComputation];
    }
}
